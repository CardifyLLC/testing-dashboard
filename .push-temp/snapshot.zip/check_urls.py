import json, subprocess, sys

API_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImR1bm9lc3lranZkbnBlYXZvanNpIiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc2MzgzMjY5NiwiZXhwIjoyMDc5NDA4Njk2fQ.fqr_GveKPZn9USpJq01oY97yrkMPf57inaiNypLe56Q"

# Fetch the order
result = subprocess.run([
    'curl', '-s',
    'https://dunoesykjvdnpeavojsi.supabase.co/rest/v1/orders?select=card_images&created_at=gte.2026-03-05T21:00:00Z&created_at=lt.2026-03-05T22:00:00Z&limit=1',
    '-H', f'apikey: {API_KEY}',
    '-H', f'Authorization: Bearer {API_KEY}'
], capture_output=True, text=True)

data = json.loads(result.stdout)
ci = data[0].get('card_images', [])
if isinstance(ci, str):
    ci = json.loads(ci)
urls = [u for u in ci if u]
print(f'Total non-empty URLs: {len(urls)}')

errors = []
ok = 0
for i, u in enumerate(urls):
    r = subprocess.run(
        ['curl', '-sI', '-o', 'nul', '-w', '%{http_code}', '--connect-timeout', '5', u],
        capture_output=True, text=True
    )
    code = r.stdout.strip()
    if code != '200':
        errors.append((i, code, u))
        print(f'  ERROR [{i}] HTTP {code}: {u[-80:]}')
    else:
        ok += 1
    if (i + 1) % 50 == 0:
        print(f'  Progress: {i+1}/{len(urls)}, errors: {len(errors)}')

print(f'\nDone: {ok} OK, {len(errors)} errors')
for i, code, u in errors:
    print(f'  [{i}] {code}: {u}')
