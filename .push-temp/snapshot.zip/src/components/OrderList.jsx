import React from 'react';
import { hasUploadedXml, isXmlOrder } from '../services/orderService';

const statusTabs = [
    { value: 'all', label: 'All' },
    { value: 'pending', label: 'Pending' },
    { value: 'paid', label: 'Paid' },
    { value: 'processing', label: 'Processing' },
    { value: 'shipped', label: 'Shipped' },
    { value: 'completed', label: 'Completed' },
    { value: 'cancelled', label: 'Cancelled' },
];

const OrderList = ({ orders, onSelectOrder, page, setPage, totalCount, pageSize, activeStatus, onChangeStatus }) => {
    const formatDate = (dateString) => {
        return new Date(dateString).toLocaleDateString('en-US', {
            year: 'numeric',
            month: 'short',
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
        });
    };

    const formatCurrency = (cents) => {
        return new Intl.NumberFormat('en-US', {
            style: 'currency',
            currency: 'USD'
        }).format(cents / 100);
    };

    const totalPages = Math.ceil(totalCount / pageSize);

    return (
        <div className="data-table-container">
            <div className="orders-filter-tabs">
                {statusTabs.map((tab) => (
                    <button
                        key={tab.value}
                        type="button"
                        className={`orders-filter-tab ${activeStatus === tab.value ? 'active' : ''}`}
                        onClick={() => onChangeStatus(tab.value)}
                    >
                        {tab.label}
                    </button>
                ))}
            </div>
            <div className="table-header" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '10px' }}>
                <span>Total Orders: {totalCount}</span>
                <div className="pagination-controls" style={{ display: 'flex', gap: '10px', alignItems: 'center' }}>
                    <button
                        disabled={page === 1}
                        onClick={() => setPage(p => Math.max(1, p - 1))}
                        style={{ padding: '5px 10px', cursor: page === 1 ? 'not-allowed' : 'pointer' }}
                    >
                        Previous
                    </button>
                    <span>Page {page} of {totalPages || 1}</span>
                    <button
                        disabled={page >= totalPages}
                        onClick={() => setPage(p => p + 1)}
                        style={{ padding: '5px 10px', cursor: page >= totalPages ? 'not-allowed' : 'pointer' }}
                    >
                        Next
                    </button>
                </div>
            </div>
            <table className="data-table">
                <thead>
                    <tr>
                        <th>Order ID</th>
                        <th>Customer</th>
                        <th>Date</th>
                        <th>Type</th>
                        <th>Status</th>
                        <th>Total</th>
                        <th>Items</th>
                    </tr>
                </thead>
                <tbody>
                    {orders.map(order => {
                        const xmlOrder = isXmlOrder(order);
                        const hasXml = hasUploadedXml(order);
                        const normalizedStatus = String(order.status || '').toLowerCase();
                        return (
                        <tr key={order.id} onClick={() => onSelectOrder(order)}>
                            <td>#{order.id.slice(0, 8)}</td>
                            <td>
                                <div style={{ fontWeight: 'bold' }}>{order.customer_name || 'Guest'}</div>
                                <div style={{ fontSize: '0.8em', color: 'var(--text-muted)' }}>{order.customer_email}</div>
                            </td>
                            <td>{formatDate(order.created_at)}</td>
                            <td>
                                <div style={{ display: 'flex', gap: '0.35rem', flexWrap: 'wrap' }}>
                                    <span className={`status-badge ${xmlOrder ? 'status-paid' : 'status-pending'}`}>
                                        {xmlOrder ? 'XML' : 'Standard'}
                                    </span>
                                    {hasXml && (
                                        <span className="status-badge" style={{ backgroundColor: '#dbeafe', color: '#1d4ed8' }}>
                                            Has XML
                                        </span>
                                    )}
                                </div>
                            </td>
                            <td>
                                <span className={`status-badge status-${normalizedStatus}`}>
                                    {order.status}
                                </span>
                            </td>
                            <td>{formatCurrency(order.total_amount_cents)}</td>
                            <td>{order.quantity} cards</td>
                        </tr>
                    )})}
                </tbody>
            </table>
        </div>
    );
};

export default OrderList;
